// import 'dart:io';
// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:photo_manager/photo_manager.dart';
// import 'package:path/path.dart' as path;
// import 'gallery_state.dart';
// import '../../app_permissions/app_permissions.dart';
//
// class GalleryCubit extends Cubit<GalleryState> {
//   GalleryCubit(this.maxSelection, this.onSelectionDone, this.isCropImage) : super(GalleryInitial());
//
//   final int maxSelection;
//   final Function(List<dynamic>) onSelectionDone;
//   final bool isCropImage;
//
//   List<AssetPathEntity> _albums = [];
//   int _currentPage = 0;
//   final int _pageSize = 60;
//   // Remove _isFetchingMore as a separate field, it will be part of the state.
//   // bool _isFetchingMore = false; // REMOVE THIS LINE
//
//
//   Future<void> loadGallery(BuildContext context, {bool isInitial = true}) async {
//     // Get the current state to check if already fetching
//     bool currentIsFetchingMore = false;
//     if (state is GalleryLoaded) {
//       currentIsFetchingMore = (state as GalleryLoaded).isFetchingMore;
//     }
//
//     if (isInitial && state is! GalleryLoading) {
//       emit(GalleryLoading());
//     } else if (!isInitial && currentIsFetchingMore) {
//       return; // Prevent multiple simultaneous fetches
//     }
//
//     // Set isFetchingMore to true when starting to load more, updating the state
//     if (state is GalleryLoaded) {
//       emit((state as GalleryLoaded).copyWith(isFetchingMore: true));
//     } else if (state is! GalleryLoading) {
//       emit(GalleryLoading()); // Should not happen if initial=false and state is not Loaded
//     }
//
//
//     bool hasPermission = await PermissionUtil.checkPermissionByPickerType(
//       'gallery',
//       context,
//     );
//     if (!hasPermission) {
//       emit(const GalleryError('Permission denied to access gallery.'));
//       // Reset fetching state in error case
//       if (state is GalleryLoaded) {
//         emit((state as GalleryLoaded).copyWith(isFetchingMore: false));
//       }
//       return;
//     }
//
//     try {
//       if (_albums.isEmpty) {
//         _albums = await PhotoManager.getAssetPathList(
//           onlyAll: true,
//           type: RequestType.image,
//         );
//       }
//
//       if (_albums.isEmpty) {
//         // Reset fetching state
//         emit(const GalleryLoaded(mediaList: [], hasReachedMax: true, isFetchingMore: false));
//         return;
//       }
//
//       final newAssets = await _albums.first.getAssetListPaged(
//         page: _currentPage,
//         size: _pageSize,
//       );
//
//       if (newAssets.isNotEmpty) {
//         _currentPage++;
//         if (state is GalleryLoaded) {
//           final currentLoadedState = state as GalleryLoaded;
//           final updatedMediaList = List<AssetEntity>.from(currentLoadedState.mediaList);
//           for (var asset in newAssets) {
//             if (!updatedMediaList.contains(asset)) {
//               updatedMediaList.add(asset);
//             }
//           }
//           emit(currentLoadedState.copyWith(
//             mediaList: updatedMediaList,
//             hasReachedMax: newAssets.length < _pageSize,
//             isFetchingMore: false, // Reset fetching state
//           ));
//         } else {
//           // This case should primarily occur after GalleryLoading or GalleryInitial
//           emit(GalleryLoaded(
//             mediaList: newAssets,
//             hasReachedMax: newAssets.length < _pageSize,
//             isFetchingMore: false, // Reset fetching state
//           ));
//         }
//       } else {
//         if (state is GalleryLoaded) {
//           final currentLoadedState = state as GalleryLoaded;
//           emit(currentLoadedState.copyWith(hasReachedMax: true, isFetchingMore: false)); // Reset fetching state
//         } else {
//           emit(const GalleryLoaded(mediaList: [], hasReachedMax: true, isFetchingMore: false)); // Reset fetching state
//         }
//       }
//     } catch (e) {
//       emit(GalleryError('Error loading gallery: $e'));
//       // Reset fetching state in error case
//       if (state is GalleryLoaded) {
//         emit((state as GalleryLoaded).copyWith(isFetchingMore: false));
//       }
//     }
//     // No finally block needed for _isFetchingMore as it's now handled in emit calls.
//   }
//
//   void toggleSelection(AssetEntity asset) {
//     if (state is GalleryLoaded) {
//       final currentLoadedState = state as GalleryLoaded;
//       final currentSelectedList = List<AssetEntity>.from(currentLoadedState.selectedAssets);
//
//       if (currentSelectedList.contains(asset)) {
//         currentSelectedList.remove(asset);
//       } else {
//         if (currentSelectedList.length < maxSelection) {
//           currentSelectedList.add(asset);
//         } else {
//           debugPrint('Max selection of $maxSelection reached.');
//         }
//       }
//       emit(currentLoadedState.copyWith(selectedAssets: currentSelectedList));
//     }
//   }
//
//   Future<void> validateAndSubmitSelection(BuildContext context) async {
//     if (state is GalleryLoaded) {
//       final currentLoadedState = state as GalleryLoaded;
//       final assets = currentLoadedState.selectedAssets;
//       List<File> allFiles = [];
//       Map<File, AssetEntity> fileToAsset = {};
//
//       for (final asset in assets) {
//         final file = await asset.file;
//         if (file != null) {
//           allFiles.add(file);
//           fileToAsset[file] = asset;
//         }
//       }
//
//       final validationResult = await _validateAndHandleImages(files: allFiles);
//
//       final validFiles = validationResult['validFiles'] as List<File>;
//       final invalidFiles = validationResult['invalidFiles'] as List<Map<String, dynamic>>;
//
//       final validAssets =
//       validFiles.map((f) => fileToAsset[f]).whereType<AssetEntity>().toList();
//
//       if (invalidFiles.isNotEmpty || validAssets.isEmpty) {
//         emit(GalleryValidationResult(
//           invalidFiles: invalidFiles,
//           validAssets: validAssets,
//         ));
//       } else if (validAssets.isNotEmpty) {
//         await _handleValidAssets(validAssets);
//       }
//     }
//   }
//
//   Future<Map<String, dynamic>> _validateAndHandleImages({
//     required List<File> files,
//   }) async {
//     List<File> validFiles = [];
//     List<Map<String, dynamic>> invalidFiles = [];
//
//     for (File file in files) {
//       final String fileName = path.basename(file.path).toLowerCase();
//       if (fileName.endsWith('.webp')) {
//         invalidFiles.add({'file': file, 'reason': 'format'});
//       } else {
//         int size = await file.length();
//         if (size > 5 * 1024 * 1024) {
//           invalidFiles.add({'file': file, 'reason': 'size'});
//         } else {
//           validFiles.add(file);
//         }
//       }
//     }
//     return {'validFiles': validFiles, 'invalidFiles': invalidFiles};
//   }
//
//   Future<void> _handleValidAssets(List<AssetEntity> validAssets) async {
//     if (isCropImage) {
//       emit(GalleryNavigateToCrop(assetsToCrop: validAssets));
//     } else {
//       onSelectionDone(validAssets);
//     }
//   }
//
//   void proceedAfterInvalidFiles(BuildContext context, List<AssetEntity> validAssets) async {
//     if (validAssets.isNotEmpty) {
//       await _handleValidAssets(validAssets);
//     }
//   }
// }