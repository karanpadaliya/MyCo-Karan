// import 'package:equatable/equatable.dart';
// import 'package:photo_manager/photo_manager.dart';
// import 'dart:io'; // Import for File type
//
// abstract class GalleryState extends Equatable {
//   const GalleryState();
//
//   @override
//   List<Object> get props => [];
// }
//
// class GalleryInitial extends GalleryState {}
//
// class GalleryLoading extends GalleryState {}
//
// class GalleryLoaded extends GalleryState {
//   final List<AssetEntity> mediaList;
//   final List<AssetEntity> selectedAssets;
//   final bool hasReachedMax;
//   final bool isFetchingMore; // ADD THIS LINE
//
//   const GalleryLoaded({
//     required this.mediaList,
//     this.selectedAssets = const [],
//     this.hasReachedMax = false,
//     this.isFetchingMore = false, // INITIALIZE THIS
//   });
//
//   GalleryLoaded copyWith({
//     List<AssetEntity>? mediaList,
//     List<AssetEntity>? selectedAssets,
//     bool? hasReachedMax,
//     bool? isFetchingMore, // ADD THIS TO COPYWITH
//   }) {
//     return GalleryLoaded(
//       mediaList: mediaList ?? this.mediaList,
//       selectedAssets: selectedAssets ?? this.selectedAssets,
//       hasReachedMax: hasReachedMax ?? this.hasReachedMax,
//       isFetchingMore: isFetchingMore ?? this.isFetchingMore, // COPY THIS
//     );
//   }
//
//   @override
//   List<Object> get props => [mediaList, selectedAssets, hasReachedMax, isFetchingMore]; // ADD THIS TO PROPS
// }
//
// class GalleryError extends GalleryState {
//   final String message;
//
//   const GalleryError(this.message);
//
//   @override
//   List<Object> get props => [message];
// }
//
// class GalleryValidationResult extends GalleryState {
//   final List<Map<String, dynamic>> invalidFiles;
//   final List<AssetEntity> validAssets;
//
//   const GalleryValidationResult({
//     required this.invalidFiles,
//     required this.validAssets,
//   });
//
//   @override
//   List<Object> get props => [invalidFiles, validAssets];
// }
//
// class GalleryNavigateToCrop extends GalleryState {
//   final List<AssetEntity> assetsToCrop;
//
//   const GalleryNavigateToCrop({required this.assetsToCrop});
//
//   @override
//   List<Object> get props => [assetsToCrop];
// }