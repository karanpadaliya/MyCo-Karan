part of 'crop_bloc.dart';

@immutable
abstract class CropEvent {}

class InitializeCropEditor extends CropEvent {
  final List<AssetEntity> assets;
  InitializeCropEditor(this.assets);
}

class UpdateCropRect extends CropEvent {
  final Rect newRect;
  UpdateCropRect(this.newRect);
}

class ConfirmCurrentCrop extends CropEvent {}

class ResetCurrentCrop extends CropEvent {}

class ChangeAspectRatio extends CropEvent {
  final CropAspectRatio aspectRatio;
  ChangeAspectRatio(this.aspectRatio);
}

class ChangeCropShape extends CropEvent {
  final CropShape shape;
  ChangeCropShape(this.shape);
}

class SelectImage extends CropEvent {
  final int index;
  SelectImage(this.index);
}

class ProcessAndSaveImages extends CropEvent {
  final BuildContext context;
  ProcessAndSaveImages(this.context);
}

class ApplyAndReturnOriginals extends CropEvent {
  final BuildContext context;
  ApplyAndReturnOriginals(this.context);
}

class UpdateImageDisplaySize extends CropEvent { // New event
  final Size newSize;
  UpdateImageDisplaySize(this.newSize);
}