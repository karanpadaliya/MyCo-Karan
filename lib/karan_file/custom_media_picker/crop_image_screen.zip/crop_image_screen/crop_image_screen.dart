import 'dart:ui' as ui;
import 'dart:typed_data';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../themes_colors/colors.dart';
import '../../custom_loader/custom_loader.dart';
import 'crop_bloc.dart';

class CropImageScreen extends StatelessWidget {
  final List<AssetEntity> assets;

  const CropImageScreen({super.key, required this.assets});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => CropBloc(assets: assets),
      child: Builder(
        builder: (context) {
          return Scaffold(
            backgroundColor: AppColors.black,
            appBar: _buildAppBar(context),
            body: _buildBody(context),
          );
        },
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) => AppBar(
    backgroundColor: AppColors.primary,
    foregroundColor: AppColors.white,
    elevation: 0,
    title: const Text(
      'Edit & Crop',
      style: TextStyle(fontWeight: FontWeight.bold),
    ),
    centerTitle: true,
    actions: [
      IconButton(
        icon: const Icon(Icons.done_all),
        onPressed: () => _showConfirmDialog(context),
      ),
    ],
  );

  Widget _buildBody(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        _buildMainImageViewer(context),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: ElevatedButton(
            onPressed: () => context.read<CropBloc>().add(ConfirmCurrentCrop()),
            style: ButtonStyle(
              backgroundColor: WidgetStatePropertyAll(AppColors.primary),
              foregroundColor: WidgetStatePropertyAll(AppColors.white),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.crop, color: AppColors.white),
                SizedBox(width: 5),
                Text('Apply'),
              ],
            ),
          ),
        ),
        _buildEditingToolbar(context),
        _buildThumbnailList(context),
      ],
    );
  }

  Widget _buildMainImageViewer(BuildContext context) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: BlocBuilder<CropBloc, CropState>(
          buildWhen:
              (previous, current) =>
                  current is CropLoaded &&
                  (previous is! CropLoaded ||
                      previous.currentIndex != current.currentIndex ||
                      previous.pendingCropRects[current.currentIndex] !=
                          current.pendingCropRects[current.currentIndex] ||
                      previous.selectedAspectRatio !=
                          current.selectedAspectRatio ||
                      previous.selectedShape != current.selectedShape ||
                      previous.currentImageData != current.currentImageData ||
                      previous.imageDisplaySize != current.imageDisplaySize),
          builder: (context, state) {
            final bloc = context.read<CropBloc>();
            if (state is CropLoading) {
              return const Center(child: CustomLoader());
            } else if (state is CropLoaded) {
              if (state.currentImageData == null) {
                return const Center(child: Text("Image data not available."));
              }
              return LayoutBuilder(
                builder: (BuildContext context, BoxConstraints constraints) {
                  final Size detectedSize = constraints.biggest;

                  if (bloc.imageDisplaySize == null ||
                      bloc.imageDisplaySize != detectedSize) {
                    Future.microtask(() {
                      bloc.add(UpdateImageDisplaySize(detectedSize));
                    });
                  }

                  return Container(
                    alignment: Alignment.center,
                    child:
                        (state.imageDisplaySize == null ||
                                state.imageDisplaySize!.isEmpty)
                            ? Image.memory(
                              state.currentImageData!,
                              fit: BoxFit.contain,
                            )
                            : RepaintBoundary(
                              child: ResizableCropArea(
                                imageData: state.currentImageData!,
                                initialRect:
                                    state.pendingCropRects[state.currentIndex],
                                onRectChanged: (newRect) {
                                  context.read<CropBloc>().add(
                                    UpdateCropRect(newRect),
                                  );
                                },
                                aspectRatio: state.selectedAspectRatio,
                                shape: state.selectedShape,
                                parentSize: state.imageDisplaySize,
                              ),
                            ),
                  );
                },
              );
            }
            return const Center(child: Text("Something went wrong."));
          },
        ),
      ),
    );
  }

  Widget _buildEditingToolbar(BuildContext context) {
    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      child: BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: 20.0, sigmaY: 20.0),
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.primary.withValues(alpha: 0.3),
          ),
          child: BlocBuilder<CropBloc, CropState>(
            buildWhen:
                (previous, current) =>
                    current is CropLoaded &&
                    (previous is! CropLoaded ||
                        previous.selectedShape != current.selectedShape ||
                        previous.selectedAspectRatio !=
                            current.selectedAspectRatio),
            builder: (context, state) {
              if (state is! CropLoaded) {
                return const SizedBox.shrink();
              }
              final loadedState = state;
              final List<CropAspectRatio> localAspectRatios = [
                CropAspectRatio(
                  label: 'Free',
                  icon: Icons.crop_free,
                  value: null,
                ),
                CropAspectRatio(
                  label: '1:1',
                  icon: Icons.crop_square,
                  value: 1.0,
                ),
                CropAspectRatio(
                  label: '4:3',
                  icon: Icons.crop_landscape,
                  value: 4.0 / 3.0,
                ),
                CropAspectRatio(
                  label: '3:4',
                  icon: Icons.crop_portrait,
                  value: 3.0 / 4.0,
                ),
                CropAspectRatio(
                  label: '16:9',
                  icon: Icons.crop_16_9,
                  value: 16.0 / 9.0,
                ),
                CropAspectRatio(
                  label: '9:16',
                  icon: Icons.crop_7_5,
                  value: 9.0 / 16.0,
                ),
              ];

              return Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _buildToolbarButton(
                          icon: Icons.refresh,
                          label: "Reset",
                          onPressed:
                              () => context.read<CropBloc>().add(
                                ResetCurrentCrop(),
                              ),
                        ),
                        _buildShapeButton(
                          context,
                          icon: Icons.rectangle_outlined,
                          shape: CropShape.rectangle,
                          isSelected:
                              loadedState.selectedShape == CropShape.rectangle,
                        ),
                        _buildShapeButton(
                          context,
                          icon: Icons.circle_outlined,
                          shape: CropShape.circle,
                          isSelected:
                              loadedState.selectedShape == CropShape.circle,
                        ),
                      ],
                    ),
                  ),
                  Divider(
                    height: 1,
                    color: AppColors.white.withValues(alpha: 0.5),
                  ),
                  if (loadedState.selectedShape == CropShape.rectangle)
                    SizedBox(
                      height: 60,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: localAspectRatios.length,
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        itemBuilder: (context, index) {
                          final ratio = localAspectRatios[index];
                          final isSelected =
                              ratio.label ==
                              loadedState.selectedAspectRatio.label;
                          return GestureDetector(
                            onTap: () {
                              context.read<CropBloc>().add(
                                ChangeAspectRatio(ratio),
                              );
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                              ),
                              alignment: Alignment.center,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    ratio.icon,
                                    color:
                                        isSelected
                                            ? AppColors.white
                                            : AppColors.white.withValues(
                                              alpha: 0.7,
                                            ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    ratio.label,
                                    style: TextStyle(
                                      fontSize: 12,
                                      color:
                                          isSelected
                                              ? AppColors.white
                                              : AppColors.white.withValues(
                                                alpha: 0.7,
                                              ),
                                      fontWeight:
                                          isSelected
                                              ? FontWeight.bold
                                              : FontWeight.normal,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildToolbarButton({
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
  }) => InkWell(
    onTap: onPressed,
    borderRadius: BorderRadius.circular(8),
    highlightColor: AppColors.primary.withValues(alpha: 0.3),
    splashColor: AppColors.primary.withValues(alpha: 0.5),
    child: Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: AppColors.secondary, size: 24),
          const SizedBox(height: 4),
          Text(
            label,
            style: const TextStyle(color: AppColors.secondary, fontSize: 12),
          ),
        ],
      ),
    ),
  );

  Widget _buildShapeButton(
    BuildContext context, {
    required IconData icon,
    required CropShape shape,
    required bool isSelected,
  }) {
    return InkWell(
      onTap: () => context.read<CropBloc>().add(ChangeCropShape(shape)),
      borderRadius: BorderRadius.circular(8),
      highlightColor: AppColors.primary.withValues(alpha: 0.3),
      splashColor: AppColors.primary.withValues(alpha: 0.5),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 24,
              color:
                  isSelected
                      ? AppColors.white
                      : AppColors.white.withValues(alpha: 0.3),
            ),
            const SizedBox(height: 4),
            Text(
              shape.toString().split('.').last.capitalize(),
              style: TextStyle(
                fontSize: 12,
                color:
                    isSelected
                        ? AppColors.white
                        : AppColors.white.withValues(alpha: 0.3),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildThumbnailList(BuildContext context) {
    return BlocBuilder<CropBloc, CropState>(
      buildWhen:
          (previous, current) =>
              current is CropLoaded &&
              (previous is! CropLoaded ||
                  previous.currentIndex != current.currentIndex ||
                  previous.croppedRects != current.croppedRects),
      builder: (context, state) {
        if (state is! CropLoaded) {
          return const SizedBox.shrink();
        }
        final loadedState = state;
        return Container(
          height: 90,
          padding: const EdgeInsets.symmetric(vertical: 10),
          color: AppColors.black.withValues(alpha: 0.5),
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: loadedState.assets.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (context, index) {
              final isSelected = index == loadedState.currentIndex;
              final isEdited = loadedState.croppedRects.containsKey(index);
              final hasChanges = isEdited;

              return GestureDetector(
                onTap: () => context.read<CropBloc>().add(SelectImage(index)),
                child: AspectRatio(
                  aspectRatio: 1,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color:
                            isSelected ? AppColors.white : Colors.transparent,
                        width: 2,
                      ),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(9),
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          FutureBuilder<Uint8List?>(
                            future: loadedState.assets[index]
                                .thumbnailDataWithSize(
                                  const ThumbnailSize(200, 200),
                                ),
                            builder:
                                (context, snapshot) =>
                                    snapshot.hasData
                                        ? Image.memory(
                                          snapshot.data!,
                                          fit: BoxFit.cover,
                                        )
                                        : Container(color: AppColors.secondary),
                          ),
                          if (hasChanges)
                            Positioned(
                              top: 4,
                              right: 4,
                              child: Container(
                                padding: const EdgeInsets.all(2),
                                decoration: BoxDecoration(
                                  color: AppColors.primary,
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  Icons.edit,
                                  size: 12,
                                  color: AppColors.white,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  void _showConfirmDialog(BuildContext context) {
    final bloc = context.read<CropBloc>();
    final bool hasAnyCrop =
        (bloc.state is CropLoaded) &&
        (bloc.state as CropLoaded).croppedRects.isNotEmpty;

    if (!hasAnyCrop) {
      bloc.add(ApplyAndReturnOriginals(context));
      return;
    }

    showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          backgroundColor: AppColors.white,
          title: Text(
            'Apply Changes',
            style: TextStyle(
              color: AppColors.primary,
              fontWeight: FontWeight.w500,
            ),
          ),
          content: Text(
            'Do you want to save the changes made to these images?',
            style: TextStyle(color: AppColors.black),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: Text(
                'Cancel',
                style: TextStyle(color: AppColors.onCancleBtn),
              ),
            ),
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: Text(
                'Confirm',
                style: TextStyle(color: AppColors.primary),
              ),
            ),
          ],
        );
      },
    ).then((confirmed) {
      if (confirmed == true) {
        bloc.add(ProcessAndSaveImages(context));
      }
    });
  }
}

class ResizableCropArea extends StatefulWidget {
  final Uint8List imageData;
  final Rect? initialRect;
  final ValueChanged<Rect> onRectChanged;
  final CropAspectRatio aspectRatio;
  final CropShape shape;
  final Size? parentSize;

  const ResizableCropArea({
    super.key,
    required this.imageData,
    this.initialRect,
    required this.onRectChanged,
    required this.aspectRatio,
    required this.shape,
    this.parentSize,
  });

  static const double minCropSize = 50.0;

  @override
  State<ResizableCropArea> createState() => _ResizableCropAreaState();
}

class _ResizableCropAreaState extends State<ResizableCropArea> {
  Rect? _rect;
  _DragHandle _activeHandle = _DragHandle.none;

  Rect? _rectOnScaleStart;
  Offset? _focalPointOnScaleStart;

  static const double _handleTouchSize = 32.0;

  @override
  void initState() {
    super.initState();
    _rect = widget.initialRect;
  }

  @override
  void didUpdateWidget(covariant ResizableCropArea oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (widget.initialRect != oldWidget.initialRect &&
        _activeHandle == _DragHandle.none &&
        _rectOnScaleStart == null) {
      _rect = widget.initialRect;
    }
  }

  _DragHandle _getHandleForPosition(Offset position) {
    if (_rect == null) return _DragHandle.none;

    final handleRects = {
      _DragHandle.topLeft: Rect.fromCenter(
        center: _rect!.topLeft,
        width: _handleTouchSize,
        height: _handleTouchSize,
      ),
      _DragHandle.topRight: Rect.fromCenter(
        center: _rect!.topRight,
        width: _handleTouchSize,
        height: _handleTouchSize,
      ),
      _DragHandle.bottomLeft: Rect.fromCenter(
        center: _rect!.bottomLeft,
        width: _handleTouchSize,
        height: _handleTouchSize,
      ),
      _DragHandle.bottomRight: Rect.fromCenter(
        center: _rect!.bottomRight,
        width: _handleTouchSize,
        height: _handleTouchSize,
      ),
    };

    for (final entry in handleRects.entries) {
      if (entry.value.contains(position)) return entry.key;
    }

    if (_rect!.contains(position)) return _DragHandle.center;
    return _DragHandle.none;
  }

  void _onScaleStart(ScaleStartDetails details) {
    _rectOnScaleStart = _rect;
    _focalPointOnScaleStart = details.focalPoint;

    if (details.pointerCount == 1) {
      _activeHandle = _getHandleForPosition(details.localFocalPoint);
    } else {
      _activeHandle = _DragHandle.none;
    }
  }

  void _onScaleUpdate(ScaleUpdateDetails details) {
    if (_rectOnScaleStart == null ||
        widget.parentSize == null ||
        widget.parentSize!.isEmpty) {
      debugPrint(
        "Warning: parentSize or initial rect not set or empty during scale update.",
      );
      return;
    }

    Rect newRect = _rectOnScaleStart!;

    Offset translationDelta = details.focalPoint - _focalPointOnScaleStart!;

    if (details.pointerCount == 1 && _activeHandle != _DragHandle.none) {
      if (_activeHandle == _DragHandle.center) {
        newRect = newRect.translate(translationDelta.dx, translationDelta.dy);
      } else {
        Offset newCorner;
        Offset oppositeCorner;

        switch (_activeHandle) {
          case _DragHandle.topLeft:
            newCorner = _rectOnScaleStart!.topLeft + translationDelta;
            oppositeCorner = _rectOnScaleStart!.bottomRight;
            break;
          case _DragHandle.topRight:
            newCorner = _rectOnScaleStart!.topRight + translationDelta;
            oppositeCorner = _rectOnScaleStart!.bottomLeft;
            break;
          case _DragHandle.bottomLeft:
            newCorner = _rectOnScaleStart!.bottomLeft + translationDelta;
            oppositeCorner = _rectOnScaleStart!.topRight;
            break;
          case _DragHandle.bottomRight:
            newCorner = _rectOnScaleStart!.bottomRight + translationDelta;
            oppositeCorner = _rectOnScaleStart!.topLeft;
            break;
          default:
            return;
        }

        newRect = Rect.fromPoints(newCorner, oppositeCorner).normalize();

        final ratio = widget.aspectRatio.value;
        if (ratio != null) {
          double currentWidth = newRect.width;
          double currentHeight = newRect.height;

          double targetWidth;
          double targetHeight;

          if (currentWidth / currentHeight > ratio) {
            targetWidth = currentHeight * ratio;
            targetHeight = currentHeight;
          } else {
            targetHeight = currentWidth / ratio;
            targetWidth = currentWidth;
          }

          targetWidth = max(ResizableCropArea.minCropSize, targetWidth);
          targetHeight = max(ResizableCropArea.minCropSize, targetHeight);

          if (_activeHandle == _DragHandle.topLeft) {
            newRect = Rect.fromLTWH(
              oppositeCorner.dx - targetWidth,
              oppositeCorner.dy - targetHeight,
              targetWidth,
              targetHeight,
            );
          } else if (_activeHandle == _DragHandle.topRight) {
            newRect = Rect.fromLTWH(
              oppositeCorner.dx,
              oppositeCorner.dy - targetHeight,
              targetWidth,
              targetHeight,
            );
          } else if (_activeHandle == _DragHandle.bottomLeft) {
            newRect = Rect.fromLTWH(
              oppositeCorner.dx - targetWidth,
              oppositeCorner.dy,
              targetWidth,
              targetHeight,
            );
          } else {
            newRect = Rect.fromLTWH(
              oppositeCorner.dx,
              oppositeCorner.dy,
              targetWidth,
              targetHeight,
            );
          }
        }
      }
    } else if (details.pointerCount > 1) {
      final Offset translation = translationDelta;

      double newWidth = _rectOnScaleStart!.width * details.scale;
      double newHeight = _rectOnScaleStart!.height * details.scale;

      if (widget.aspectRatio.value != null) {
        final ratio = widget.aspectRatio.value!;
        if (newWidth / newHeight > ratio) {
          newWidth = newHeight * ratio;
        } else {
          newHeight = newWidth / ratio;
        }
      }

      newWidth = newWidth.clamp(
        ResizableCropArea.minCropSize,
        widget.parentSize!.width,
      );
      newHeight = newHeight.clamp(
        ResizableCropArea.minCropSize,
        widget.parentSize!.height,
      );

      final newCenter = _rectOnScaleStart!.center + translation;

      newRect = Rect.fromCenter(
        center: newCenter,
        width: newWidth,
        height: newHeight,
      );
    } else {
      return;
    }

    double finalWidth = newRect.width.clamp(
      ResizableCropArea.minCropSize,
      widget.parentSize!.width,
    );
    double finalHeight = newRect.height.clamp(
      ResizableCropArea.minCropSize,
      widget.parentSize!.height,
    );

    double left = newRect.left.clamp(
      0.0,
      widget.parentSize!.width - finalWidth,
    );
    double top = newRect.top.clamp(
      0.0,
      widget.parentSize!.height - finalHeight,
    );

    newRect = Rect.fromLTWH(left, top, finalWidth, finalHeight);

    setState(() {
      _rect = newRect;
      widget.onRectChanged(_rect!);
    });
  }

  void _onScaleEnd(ScaleEndDetails details) {
    _activeHandle = _DragHandle.none;
    _rectOnScaleStart = null;
    _focalPointOnScaleStart = null;
  }

  @override
  Widget build(BuildContext context) {
    if (widget.parentSize == null ||
        widget.parentSize!.isEmpty ||
        _rect == null) {
      return Image.memory(widget.imageData, fit: BoxFit.contain);
    }

    return Stack(
      fit: StackFit.expand,
      children: [
        Image.memory(widget.imageData, fit: BoxFit.contain),
        Positioned.fill(
          child: GestureDetector(
            onScaleStart: _onScaleStart,
            onScaleUpdate: _onScaleUpdate,
            onScaleEnd: _onScaleEnd,
            child: CustomPaint(
              painter: _CropRectPainter(rect: _rect!, shape: widget.shape),
            ),
          ),
        ),
      ],
    );
  }
}

enum _DragHandle { none, center, topLeft, topRight, bottomLeft, bottomRight }

class _CropRectPainter extends CustomPainter {
  final Rect rect;
  final CropShape shape;
  static const double _handleSize = 8.0;

  final Paint _backgroundDimPaint =
      Paint()..color = Colors.black.withValues(alpha: 0.6);

  final Paint _borderPaint =
      Paint()
        ..color = AppColors.primary
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3.0;
  final Paint _handlePaint = Paint()..color = AppColors.white;

  _CropRectPainter({required this.rect, required this.shape});

  @override
  void paint(Canvas canvas, Size size) {
    final Path fullPath =
        Path()..addRect(Rect.fromLTWH(0, 0, size.width, size.height));

    final Path cropPath = Path();
    if (shape == CropShape.rectangle) {
      cropPath.addRect(rect);
    } else {
      cropPath.addOval(rect);
    }

    final Path dimmedAreaPath = Path.combine(
      PathOperation.difference,
      fullPath,
      cropPath,
    );

    canvas.drawPath(dimmedAreaPath, _backgroundDimPaint);

    if (shape == CropShape.rectangle) {
      canvas.drawRect(rect, _borderPaint);
    } else {
      canvas.drawOval(rect, _borderPaint);
    }

    if (shape == CropShape.rectangle) {
      canvas.drawCircle(rect.topLeft, _handleSize, _handlePaint);
      canvas.drawCircle(rect.topRight, _handleSize, _handlePaint);
      canvas.drawCircle(rect.bottomLeft, _handleSize, _handlePaint);
      canvas.drawCircle(rect.bottomRight, _handleSize, _handlePaint);
    }
  }

  @override
  bool shouldRepaint(covariant _CropRectPainter oldDelegate) {
    return oldDelegate.rect != rect || oldDelegate.shape != shape;
  }
}
