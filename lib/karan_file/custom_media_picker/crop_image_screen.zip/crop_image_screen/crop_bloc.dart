// crop_bloc.dart
// Imports first
import 'dart:io';
import 'dart:ui' as ui;
import 'dart:typed_data';
import 'dart:math';
import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:meta/meta.dart';
import 'package:photo_manager/photo_manager.dart';
import '../../custom_loader/custom_loader.dart';
import 'crop_image_screen.dart';

// Then part directives
part 'crop_event.dart';

part 'crop_state.dart';

// --- THESE ARE THE COMMON DEFINITIONS. THEY SHOULD ONLY LIVE HERE. ---
extension ColorExtension on Color {
  Color withValues({int? red, int? green, int? blue, double? alpha}) {
    return Color.fromARGB(
      (alpha == null ? this.alpha : (255 * alpha).round()).clamp(0, 255),
      red ?? this.red,
      green ?? this.green,
      blue ?? this.blue,
    );
  }
}

extension RectExtension on Rect {
  Rect normalize() {
    return Rect.fromLTRB(
      min(left, right),
      min(top, bottom),
      max(left, right),
      max(top, bottom),
    );
  }
}

enum CropShape { rectangle, circle }

class CropAspectRatio {
  final String label;
  final double? value;
  final IconData icon;

  const CropAspectRatio({required this.label, this.value, required this.icon});
}

const List<CropAspectRatio> _aspectRatios = [
  CropAspectRatio(label: 'Free', icon: Icons.crop_free, value: null),
  CropAspectRatio(label: '1:1', icon: Icons.crop_square, value: 1.0),
  CropAspectRatio(label: '4:3', icon: Icons.crop_landscape, value: 4.0 / 3.0),
  CropAspectRatio(label: '3:4', icon: Icons.crop_portrait, value: 3.0 / 4.0),
  CropAspectRatio(label: '16:9', icon: Icons.crop_16_9, value: 16.0 / 9.0),
  CropAspectRatio(label: '9:16', icon: Icons.crop_7_5, value: 9.0 / 16.0),
];

extension StringExtension on String {
  String capitalize() {
    if (isEmpty) return this;
    return "${this[0].toUpperCase()}${substring(1)}";
  }
}
// --- END OF COMMON DEFINITIONS ---

class CropBloc extends Bloc<CropEvent, CropState> {
  final List<AssetEntity> assets;
  final GlobalKey _imageContainerKey =
      GlobalKey(); // Kept for other potential uses, not size detection now

  // Make this publicly accessible via a getter
  Size? get imageDisplaySize =>
      (state is CropLoaded) ? (state as CropLoaded).imageDisplaySize : null;

  CropBloc({required this.assets}) : super(CropInitial()) {
    on<InitializeCropEditor>(_onInitializeCropEditor);
    on<UpdateCropRect>(_onUpdateCropRect);
    on<ConfirmCurrentCrop>(_onConfirmCurrentCrop);
    on<ResetCurrentCrop>(_onResetCurrentCrop);
    on<ChangeAspectRatio>(_onChangeAspectRatio);
    on<ChangeCropShape>(_onChangeCropShape);
    on<SelectImage>(_onSelectImage);
    on<ProcessAndSaveImages>(_onProcessAndSaveImages);
    on<ApplyAndReturnOriginals>(_onApplyAndReturnOriginals);
    on<UpdateImageDisplaySize>(_onUpdateImageDisplaySize);

    add(InitializeCropEditor(assets));
  }

  GlobalKey get imageContainerKey => _imageContainerKey;

  Future<void> _onInitializeCropEditor(
    InitializeCropEditor event,
    Emitter<CropState> emit,
  ) async {
    emit(CropLoading());

    final pendingCropRects = <int, Rect>{};
    final croppedRects = <int, Rect>{};
    final cropShapes = <int, CropShape>{};
    final cropAspectRatios = <int, CropAspectRatio>{};

    // Temporarily set to Rect.zero. The UpdateImageDisplaySize event will
    // trigger recalculation once the actual imageDisplaySize is known.
    pendingCropRects[0] = Rect.zero;

    cropShapes[0] = CropShape.rectangle;
    cropAspectRatios[0] = _aspectRatios.first;

    final imageData = await _getImagePreview(0);

    emit(
      CropLoaded(
        assets: event.assets,
        currentIndex: 0,
        pendingCropRects: pendingCropRects,
        croppedRects: croppedRects,
        cropShapes: cropShapes,
        cropAspectRatios: cropAspectRatios,
        selectedAspectRatio: _aspectRatios.first,
        selectedShape: CropShape.rectangle,
        imageDisplaySize: null,
        // Start with null, will be updated by UI
        currentImageData: imageData,
      ),
    );
  }

  Future<void> _onUpdateImageDisplaySize(
    UpdateImageDisplaySize event,
    Emitter<CropState> emit,
  ) async {
    if (state is CropLoaded) {
      final currentState = state as CropLoaded;

      // Only update if the size has actually changed or if it was null initially
      if (currentState.imageDisplaySize != event.newSize) {
        // Here, we update the imageDisplaySize in the state directly,
        // which will then be reflected by the bloc.imageDisplaySize getter.
        final int currentIndex = currentState.currentIndex;
        final Rect? currentPendingRect =
            currentState.pendingCropRects[currentIndex];

        // If the current rect is null, zero, or empty, set a new one based on detected size
        if (currentPendingRect == null ||
            currentPendingRect == Rect.zero ||
            currentPendingRect.isEmpty) {
          final newInitialRect = Rect.fromCenter(
            center: event.newSize.center(Offset.zero),
            // Use event.newSize directly
            width: event.newSize.width * 0.8,
            height: event.newSize.height * 0.8,
          );

          final newPendingCropRects = Map<int, Rect>.from(
            currentState.pendingCropRects,
          )..[currentIndex] = newInitialRect;

          emit(
            currentState.copyWith(
              imageDisplaySize: event.newSize, // Update state with new size
              pendingCropRects: newPendingCropRects,
            ),
          );
          // Apply aspect ratio immediately after setting the initial rect with correct size
          _applyAspectRatio(
            emit,
            currentIndex,
            currentState.selectedAspectRatio,
            newPendingCropRects,
            event.newSize, // Pass new size
          );
        } else {
          // If rect was already set (e.g., from a previous image selection),
          // just update the display size in state.
          emit(
            currentState.copyWith(
              imageDisplaySize: event.newSize, // Update state with new size
            ),
          );
        }
      }
    }
  }

  Future<void> _onUpdateCropRect(
    UpdateCropRect event,
    Emitter<CropState> emit,
  ) async {
    if (state is CropLoaded) {
      final currentState = state as CropLoaded;
      final newPendingCropRects = Map<int, Rect>.from(
        currentState.pendingCropRects,
      )..[currentState.currentIndex] = event.newRect;

      emit(currentState.copyWith(pendingCropRects: newPendingCropRects));
    }
  }

  Future<void> _onConfirmCurrentCrop(
    ConfirmCurrentCrop event,
    Emitter<CropState> emit,
  ) async {
    if (state is CropLoaded) {
      final currentState = state as CropLoaded;
      final newCroppedRects = Map<int, Rect>.from(currentState.croppedRects);
      if (currentState.pendingCropRects.containsKey(
        currentState.currentIndex,
      )) {
        newCroppedRects[currentState.currentIndex] =
            currentState.pendingCropRects[currentState.currentIndex]!;
      }

      final newCropShapes = Map<int, CropShape>.from(currentState.cropShapes)
        ..[currentState.currentIndex] = currentState.selectedShape;
      final newCropAspectRatios = Map<int, CropAspectRatio>.from(
        currentState.cropAspectRatios,
      )..[currentState.currentIndex] = currentState.selectedAspectRatio;

      emit(
        currentState.copyWith(
          croppedRects: newCroppedRects,
          cropShapes: newCropShapes,
          cropAspectRatios: newCropAspectRatios,
        ),
      );
    }
  }

  Future<void> _onResetCurrentCrop(
    ResetCurrentCrop event,
    Emitter<CropState> emit,
  ) async {
    if (state is CropLoaded) {
      final currentState = state as CropLoaded;
      final newPendingCropRects = Map<int, Rect>.from(
        currentState.pendingCropRects,
      )..remove(currentState.currentIndex);
      final newCroppedRects = Map<int, Rect>.from(currentState.croppedRects)
        ..remove(currentState.currentIndex);
      final newCropShapes = Map<int, CropShape>.from(currentState.cropShapes)
        ..remove(currentState.currentIndex);
      final newCropAspectRatios = Map<int, CropAspectRatio>.from(
        currentState.cropAspectRatios,
      )..remove(currentState.currentIndex);

      // Re-initialize for the current index based on current imageDisplaySize
      final initialRect =
          (currentState.imageDisplaySize != null &&
                  !currentState.imageDisplaySize!.isEmpty)
              ? Rect.fromCenter(
                center: currentState.imageDisplaySize!.center(Offset.zero),
                width: currentState.imageDisplaySize!.width * 0.8,
                height: currentState.imageDisplaySize!.height * 0.8,
              )
              : Rect.zero; // Fallback

      newPendingCropRects[currentState.currentIndex] = initialRect;
      newCropShapes[currentState.currentIndex] = CropShape.rectangle;
      newCropAspectRatios[currentState.currentIndex] = _aspectRatios.first;

      emit(
        currentState.copyWith(
          pendingCropRects: newPendingCropRects,
          croppedRects: newCroppedRects,
          cropShapes: newCropShapes,
          cropAspectRatios: newCropAspectRatios,
          selectedShape: CropShape.rectangle,
          selectedAspectRatio: _aspectRatios.first,
        ),
      );
      // Only apply aspect ratio if imageDisplaySize is available
      if (currentState.imageDisplaySize != null &&
          !currentState.imageDisplaySize!.isEmpty) {
        _applyAspectRatio(
          emit,
          currentState.currentIndex,
          _aspectRatios.first,
          newPendingCropRects,
          currentState.imageDisplaySize!,
        );
      }
    }
  }

  Future<void> _onChangeAspectRatio(
    ChangeAspectRatio event,
    Emitter<CropState> emit,
  ) async {
    if (state is CropLoaded) {
      final currentState = state as CropLoaded;
      final newCropAspectRatios = Map<int, CropAspectRatio>.from(
        currentState.cropAspectRatios,
      )..[currentState.currentIndex] = event.aspectRatio;

      emit(
        currentState.copyWith(
          selectedAspectRatio: event.aspectRatio,
          cropAspectRatios: newCropAspectRatios,
        ),
      );
      // Only apply aspect ratio if imageDisplaySize is available
      if (currentState.imageDisplaySize != null &&
          !currentState.imageDisplaySize!.isEmpty) {
        _applyAspectRatio(
          emit,
          currentState.currentIndex,
          event.aspectRatio,
          currentState.pendingCropRects,
          currentState.imageDisplaySize!,
        );
      }
    }
  }

  Future<void> _onChangeCropShape(
    ChangeCropShape event,
    Emitter<CropState> emit,
  ) async {
    if (state is CropLoaded) {
      final currentState = state as CropLoaded;
      final newCropShapes = Map<int, CropShape>.from(currentState.cropShapes)
        ..[currentState.currentIndex] = event.shape;

      CropAspectRatio newSelectedAspectRatio = currentState.selectedAspectRatio;
      if (event.shape == CropShape.circle) {
        final oneToOneRatio = _aspectRatios.firstWhere(
          (ratio) => ratio.label == '1:1',
          orElse: () => _aspectRatios.first,
        );
        newSelectedAspectRatio = oneToOneRatio;
      } else {
        newSelectedAspectRatio =
            currentState.cropAspectRatios[currentState.currentIndex] ??
            _aspectRatios.first;
      }

      emit(
        currentState.copyWith(
          selectedShape: event.shape,
          cropShapes: newCropShapes,
          selectedAspectRatio: newSelectedAspectRatio,
        ),
      );
      // Only apply aspect ratio if imageDisplaySize is available
      if (currentState.imageDisplaySize != null &&
          !currentState.imageDisplaySize!.isEmpty) {
        _applyAspectRatio(
          emit,
          currentState.currentIndex,
          newSelectedAspectRatio,
          currentState.pendingCropRects,
          currentState.imageDisplaySize!,
        );
      }
    }
  }

  Future<void> _onSelectImage(
    SelectImage event,
    Emitter<CropState> emit,
  ) async {
    if (state is CropLoaded) {
      final currentState = state as CropLoaded;
      emit(CropLoading());

      final newSelectedIndex = event.index;
      final imageData = await _getImagePreview(newSelectedIndex);

      final newPendingCropRects = Map<int, Rect>.from(
        currentState.pendingCropRects,
      );
      final newCropShapes = Map<int, CropShape>.from(currentState.cropShapes);
      final newCropAspectRatios = Map<int, CropAspectRatio>.from(
        currentState.cropAspectRatios,
      );

      if (!newPendingCropRects.containsKey(newSelectedIndex)) {
        // If the imageDisplaySize is already known, initialize with it.
        // Otherwise, it will be Rect.zero and handled by _onUpdateImageDisplaySize
        // when the size comes in.
        final initialRect =
            (currentState.imageDisplaySize != null &&
                    !currentState.imageDisplaySize!.isEmpty)
                ? Rect.fromCenter(
                  center: currentState.imageDisplaySize!.center(Offset.zero),
                  width: currentState.imageDisplaySize!.width * 0.8,
                  height: currentState.imageDisplaySize!.height * 0.8,
                )
                : Rect.zero; // Fallback to Rect.zero

        newPendingCropRects[newSelectedIndex] = initialRect;
        newCropShapes[newSelectedIndex] = CropShape.rectangle;
        newCropAspectRatios[newSelectedIndex] = _aspectRatios.first;
      }

      final selectedAspectRatioForImage =
          newCropAspectRatios[newSelectedIndex]!;
      final selectedShapeForImage = newCropShapes[newSelectedIndex]!;

      emit(
        currentState.copyWith(
          currentIndex: newSelectedIndex,
          selectedAspectRatio: selectedAspectRatioForImage,
          selectedShape: selectedShapeForImage,
          currentImageData: imageData,
          pendingCropRects: newPendingCropRects,
          cropShapes: newCropShapes,
          cropAspectRatios: newCropAspectRatios,
          // imageDisplaySize is updated by UpdateImageDisplaySize event, not directly here
        ),
      );

      // Only apply aspect ratio if imageDisplaySize is available
      if (currentState.imageDisplaySize != null &&
          !currentState.imageDisplaySize!.isEmpty) {
        _applyAspectRatio(
          emit,
          newSelectedIndex,
          selectedAspectRatioForImage,
          newPendingCropRects,
          currentState.imageDisplaySize!,
        );
      }
    }
  }

  Future<Uint8List?> _getImagePreview(int index) async {
    return assets[index].thumbnailDataWithSize(const ThumbnailSize(1080, 1080));
  }

  void _applyAspectRatio(
    Emitter<CropState> emit,
    int currentIndex,
    CropAspectRatio selectedAspectRatio,
    Map<int, Rect> pendingCropRects,
    Size imageDisplaySize, // This size is now reliably passed
  ) {
    if (pendingCropRects.isEmpty ||
        !pendingCropRects.containsKey(currentIndex) ||
        imageDisplaySize.isEmpty) {
      return;
    }

    final ratio = selectedAspectRatio.value;
    if (ratio == null) return;

    Rect currentRect = pendingCropRects[currentIndex]!;
    double newWidth = currentRect.width;
    double newHeight = newWidth / ratio;

    if (newHeight > imageDisplaySize.height) {
      newHeight = imageDisplaySize.height;
      newWidth = newHeight * ratio;
    }
    if (newWidth > imageDisplaySize.width) {
      newWidth = imageDisplaySize.width;
      newHeight = newWidth / ratio;
    }

    newWidth = max(ResizableCropArea.minCropSize, newWidth);
    newHeight = max(ResizableCropArea.minCropSize, newHeight);

    final updatedRect = Rect.fromCenter(
      center: currentRect.center,
      width: newWidth,
      height: newHeight,
    );

    final newPendingCropRects = Map<int, Rect>.from(pendingCropRects)
      ..[currentIndex] = updatedRect;

    if (state is CropLoaded) {
      emit(
        (state as CropLoaded).copyWith(pendingCropRects: newPendingCropRects),
      );
    }
  }

  Future<void> _onProcessAndSaveImages(
    ProcessAndSaveImages event,
    Emitter<CropState> emit,
  ) async {
    if (state is! CropLoaded) return;

    final currentState = state as CropLoaded;
    showDialog(
      context: event.context,
      barrierDismissible: false,
      builder: (BuildContext context) => const Center(child: CustomLoader()),
    );

    final List<File> finalFiles = [];

    for (int i = 0; i < currentState.assets.length; i++) {
      final originalAsset = currentState.assets[i];
      File? originalFile = await originalAsset.file;
      if (originalFile == null) continue;

      Rect? cropRectFromUI = currentState.croppedRects[i];
      final cropShape = currentState.cropShapes[i] ?? CropShape.rectangle;

      if (cropRectFromUI == null) {
        finalFiles.add(originalFile);
        continue;
      }

      try {
        final bytes = await originalFile.readAsBytes();
        final codec = await ui.instantiateImageCodec(bytes);
        ui.Image originalImage = (await codec.getNextFrame()).image;

        Size originalImageNaturalSize = Size(
          originalImage.width.toDouble(),
          originalImage.height.toDouble(),
        );
        ui.Image imageToCropFrom = originalImage;

        Size imageToCropFromSize = Size(
          imageToCropFrom.width.toDouble(),
          imageToCropFrom.height.toDouble(),
        );

        Rect finalCropSourceRect;

        final displayAreaSize = currentState.imageDisplaySize!;
        final fittedBoxResult = applyBoxFit(
          BoxFit.contain,
          originalImageNaturalSize,
          displayAreaSize,
        );
        final Rect displayedImageRectInUI = Alignment.center.inscribe(
          fittedBoxResult.destination,
          Rect.fromLTWH(0, 0, displayAreaSize.width, displayAreaSize.height),
        );

        double scaleX =
            imageToCropFromSize.width / displayedImageRectInUI.width;
        double scaleY =
            imageToCropFromSize.height / displayedImageRectInUI.height;

        final double translatedCropLeft =
            (cropRectFromUI.left - displayedImageRectInUI.left);
        final double translatedCropTop =
            (cropRectFromUI.top - displayedImageRectInUI.top);

        finalCropSourceRect = Rect.fromLTWH(
          translatedCropLeft * scaleX,
          translatedCropTop * scaleY,
          cropRectFromUI.width * scaleX,
          cropRectFromUI.height * scaleY,
        );

        finalCropSourceRect = finalCropSourceRect.intersect(
          Rect.fromLTWH(
            0,
            0,
            imageToCropFromSize.width,
            imageToCropFromSize.height,
          ),
        );

        final ui.PictureRecorder finalRecorder = ui.PictureRecorder();
        final Canvas finalCanvas = Canvas(finalRecorder);
        final Paint paint = Paint()..isAntiAlias = true;

        final outputRect = Rect.fromLTWH(
          0,
          0,
          finalCropSourceRect.width,
          finalCropSourceRect.height,
        );

        if (cropShape == CropShape.circle) {
          finalCanvas.clipPath(Path()..addOval(outputRect));
        }

        finalCanvas.drawImageRect(
          imageToCropFrom,
          finalCropSourceRect,
          outputRect,
          paint,
        );

        final ui.Picture finalPicture = finalRecorder.endRecording();
        final ui.Image croppedImage = await finalPicture.toImage(
          outputRect.width.toInt(),
          outputRect.height.toInt(),
        );
        final ByteData? byteData = await croppedImage.toByteData(
          format: ui.ImageByteFormat.png,
        );

        imageToCropFrom.dispose();

        if (byteData == null) {
          finalFiles.add(originalFile);
          continue;
        }

        final tempDir = Directory.systemTemp;
        final file = File(
          '${tempDir.path}/cropped_${DateTime.now().millisecondsSinceEpoch}.png',
        );
        await file.writeAsBytes(byteData.buffer.asUint8List());
        finalFiles.add(file);
      } catch (e) {
        debugPrint('Error processing image at index $i: $e');
        finalFiles.add(originalFile);
      }
    }

    if (Navigator.of(event.context).canPop()) {
      Navigator.pop(event.context);
    }
    if (Navigator.of(event.context).canPop()) {
      Navigator.pop(event.context, finalFiles);
    }
  }

  Future<void> _onApplyAndReturnOriginals(
    ApplyAndReturnOriginals event,
    Emitter<CropState> emit,
  ) async {
    if (state is! CropLoaded) return;

    final currentState = state as CropLoaded;

    showDialog(
      context: event.context,
      barrierDismissible: false,
      builder: (BuildContext context) => const Center(child: CustomLoader()),
    );
    final originalFiles = await Future.wait(
      currentState.assets.map((e) => e.file),
    );
    if (Navigator.of(event.context).canPop()) {
      Navigator.pop(event.context);
    }
    if (Navigator.of(event.context).canPop()) {
      Navigator.pop(event.context, originalFiles.whereType<File>().toList());
    }
  }
}
