part of 'crop_bloc.dart';


@immutable
abstract class CropState {}

class CropInitial extends CropState {}

class CropLoading extends CropState {
  final String message;
  CropLoading({this.message = 'Loading...'});
}

class CropError extends CropState {
  final String message;
  CropError(this.message);
}

class CropLoaded extends CropState {
  final List<AssetEntity> assets;
  final int currentIndex;
  final Map<int, Rect> pendingCropRects;
  final Map<int, Rect> croppedRects;
  final Map<int, CropShape> cropShapes;
  final Map<int, CropAspectRatio> cropAspectRatios;
  final CropAspectRatio selectedAspectRatio;
  final CropShape selectedShape;
  final Size? imageDisplaySize;
  final Uint8List? currentImageData;

  CropLoaded({
    required this.assets,
    required this.currentIndex,
    required this.pendingCropRects,
    required this.croppedRects,
    required this.cropShapes,
    required this.cropAspectRatios,
    required this.selectedAspectRatio,
    required this.selectedShape,
    this.imageDisplaySize,
    this.currentImageData,
  });

  CropLoaded copyWith({
    int? currentIndex,
    Map<int, Rect>? pendingCropRects,
    Map<int, Rect>? croppedRects,
    Map<int, CropShape>? cropShapes,
    Map<int, CropAspectRatio>? cropAspectRatios,
    CropAspectRatio? selectedAspectRatio,
    CropShape? selectedShape,
    Size? imageDisplaySize,
    Uint8List? currentImageData,
  }) {
    return CropLoaded(
      assets: assets,
      currentIndex: currentIndex ?? this.currentIndex,
      pendingCropRects: pendingCropRects ?? Map.from(this.pendingCropRects),
      croppedRects: croppedRects ?? Map.from(this.croppedRects),
      cropShapes: cropShapes ?? Map.from(this.cropShapes),
      cropAspectRatios: cropAspectRatios ?? Map.from(this.cropAspectRatios),
      selectedAspectRatio: selectedAspectRatio ?? this.selectedAspectRatio,
      selectedShape: selectedShape ?? this.selectedShape,
      imageDisplaySize: imageDisplaySize ?? this.imageDisplaySize,
      currentImageData: currentImageData ?? this.currentImageData,
    );
  }
}